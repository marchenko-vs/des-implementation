DES with CBC is working correctly
